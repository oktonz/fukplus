<?php
class ModelOpenbayVersion extends Model {
	public function version() {
		return (int)2936;
	}
}